const NotFound = () => (
    <div className="dots flex min-h-screen items-center justify-center bg-background px-4">
        <div className="text-center">
            <h1 className="font-head text-[120px] font-light leading-none tracking-[0.06em] text-primary">404</h1>
            <p className="mb-6 mt-2 font-head text-xl text-muted-foreground">Такой страницы нет — возможно, она переехала</p>
            <a href="/" className="inline-block rounded-full bg-primary px-6 py-3 font-head font-medium text-primary-foreground hover:brightness-110">
                Вернуться на главную
            </a>
        </div>
    </div>
);

export default NotFound;
