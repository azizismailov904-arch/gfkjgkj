import { Link } from "@tanstack/react-router";
import { COMPANY, NAV } from "@/data/site";
import { CATEGORIES } from "@/data/services";

export default function Footer() {
  return (
    <footer className="border-t border-border bg-card px-3 pb-28 pt-16 sm:px-5 md:pb-10">
      <div className="mx-auto max-w-[1400px]">
        <p className="font-head text-[13vw] font-light uppercase leading-[0.9] tracking-[0.04em] text-foreground/10 md:text-[9vw]">
          БелСтройВысоты
        </p>
        <div className="mt-10 grid gap-10 md:grid-cols-4">
          <div>
            <p className="font-head text-lg">{COMPANY.legal}</p>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
              Команда промышленных альпинистов. Высотные работы в Белгороде и Белгородской области. Ведущий поставщик мастики ТЭКТОР®.
            </p>
          </div>
          <div>
            <p className="eyebrow mb-4">Навигация</p>
            <ul className="grid gap-2 font-head text-sm">
              {NAV.map((n) => <li key={n.to}><Link to={n.to} className="hover:text-primary">{n.label}</Link></li>)}
            </ul>
          </div>
          <div>
            <p className="eyebrow mb-4">Услуги</p>
            <ul className="grid gap-2 font-head text-sm">
              {CATEGORIES.map((c) => (
                <li key={c.slug}><Link to="/{$slug}.html" params={{ slug: c.slug }} className="hover:text-primary">{c.title}</Link></li>
              ))}
              <li><Link to="/{$slug}.html" params={{ slug: "remont-elevatorov" }} className="hover:text-primary">Ремонт элеваторов</Link></li>
            </ul>
          </div>
          <div>
            <p className="eyebrow mb-4">Контакты</p>
            <div className="grid gap-2 font-head text-sm">
              <p className="text-muted-foreground">{COMPANY.address}</p>
              <a href={COMPANY.phoneHref} className="text-lg hover:text-primary">{COMPANY.phone}</a>
              <a href={COMPANY.phone2Href} className="hover:text-primary">{COMPANY.phone2}</a>
              <a href={`mailto:${COMPANY.email}`} className="hover:text-primary">{COMPANY.email}</a>
            </div>
          </div>
        </div>
        <div className="mt-12 flex flex-wrap justify-between gap-4 border-t border-border pt-6 font-head text-xs text-muted-foreground">
          <p>© 2026 {COMPANY.legal}</p>
          <div className="flex gap-5">
            <Link to="/polzovatelskoe-soglashenie.html" className="hover:text-primary">Пользовательское соглашение</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}