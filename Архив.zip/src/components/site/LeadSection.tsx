import Icon from "@/components/ui/icon";
import LeadForm from "@/components/site/LeadForm";
import { COMPANY, HERO_IMAGE } from "@/data/site";

export default function LeadSection({ title = "Рассчитаем стоимость за 15 минут" }: { title?: string }) {
  return (
    <section id="lead" className="px-3 py-20 sm:px-5 md:py-28">
      <div className="mx-auto grid max-w-[1400px] gap-2 lg:grid-cols-[1fr_1.1fr]">
        <div data-reveal="left" className="tile relative flex min-h-[420px] flex-col justify-between overflow-hidden p-6 md:p-10"
          style={{ backgroundImage: `url(${HERO_IMAGE})`, backgroundSize: "cover", backgroundPosition: "60% 40%" }}>
          <div className="absolute inset-0 bg-gradient-to-br from-hero-shade/90 via-hero-shade/60 to-hero-shade/20" />
          <div className="relative">
            <p className="eyebrow mb-4 text-primary">05 — Заявка</p>
            <h2 className="section-title max-w-lg">{title}</h2>
            <p className="mt-5 max-w-md text-muted-foreground">
              Опишите задачу, приложите фото — инженер оценит объём и назовёт цену. Выезд на объект и консультация бесплатно.
            </p>
          </div>
          <div className="relative mt-10 grid gap-3 font-head">
            <a href={COMPANY.phoneHref} className="flex items-center gap-3 text-2xl transition hover:text-primary md:text-3xl">
              <Icon name="Phone" size={22} className="text-primary" /> {COMPANY.phone}
            </a>
            <a href={COMPANY.phone2Href} className="flex items-center gap-3 text-muted-foreground transition hover:text-primary">
              <Icon name="PhoneCall" size={18} /> {COMPANY.phone2}
            </a>
            <a href={`mailto:${COMPANY.email}`} className="flex items-center gap-3 text-muted-foreground transition hover:text-primary">
              <Icon name="Mail" size={18} /> {COMPANY.email}
            </a>
          </div>
        </div>
        <div data-reveal="right" data-glow className="tile bg-card/85 p-5 backdrop-blur-md md:p-10">
          <p className="mb-6 font-head text-xl md:text-2xl">Заявка на расчёт</p>
          <LeadForm />
        </div>
      </div>
    </section>
  );
}
