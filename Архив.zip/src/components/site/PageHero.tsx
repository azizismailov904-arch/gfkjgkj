import type { ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import Icon from "@/components/ui/icon";
import { HERO_IMAGE } from "@/data/site";

type Crumb = { label: string; to?: string; params?: Record<string, string> };
type Props = { title: ReactNode; lead?: ReactNode; crumbs?: Crumb[]; image?: string; children?: ReactNode };

export default function PageHero({ title, lead, crumbs = [], image = HERO_IMAGE, children }: Props) {
  return (
    <section className="hero-stage relative overflow-hidden bg-background bg-cover bg-center px-3 pb-10 pt-28 sm:px-5 md:pb-14 md:pt-36"
      style={{ backgroundImage: `url(${image})` }}>
      <div className="absolute inset-0 z-0 bg-hero-shade/60" />
      <div className="relative z-[1] mx-auto max-w-[1400px]">
        <nav className="mb-8 flex flex-wrap items-center gap-2 font-head text-xs uppercase tracking-[0.14em] text-muted-foreground">
          <Link to="/" className="hover:text-primary">Главная</Link>
          {crumbs.map((c) => (
            <span key={c.label} className="flex items-center gap-2">
              <Icon name="ChevronRight" size={12} />
              {c.to ? (
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                <Link to={c.to as any} params={c.params as any} className="hover:text-primary">{c.label}</Link>
              ) : (
                <span className="text-foreground">{c.label}</span>
              )}
            </span>
          ))}
        </nav>
        <h1 className="max-w-5xl animate-rise font-head text-[40px] font-light uppercase leading-[1] tracking-[0.05em] sm:text-6xl md:text-[80px]">
          {title}
        </h1>
        {lead && <p className="mt-6 max-w-2xl animate-rise text-muted-foreground md:text-lg" style={{ animationDelay: "0.1s" }}>{lead}</p>}
        {children}
      </div>
    </section>
  );
}
