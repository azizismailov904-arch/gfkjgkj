import { useState } from "react";
import { Link } from "@tanstack/react-router";
import Icon from "@/components/ui/icon";
import Lightbox from "@/components/site/Lightbox";
import { GALLERY } from "@/data/gallery";

const PICK = [0, 9, 24, 12, 16, 21, 28];

export default function Works() {
  const items = PICK.map((i) => GALLERY[i]);
  const [idx, setIdx] = useState<number | null>(null);
  const spans = ["md:col-span-2 md:row-span-2", "", "", "md:row-span-2", "", "md:col-span-2", ""];

  return (
    <section id="works" className="px-3 py-20 sm:px-5 md:py-28">
      <div className="mx-auto max-w-[1400px]">
        <div data-reveal className="mb-10 flex flex-wrap items-end justify-between gap-6 md:mb-14">
          <div>
            <p className="eyebrow mb-4">04 — Объекты</p>
            <h2 className="section-title">Фото наших<br />работ</h2>
          </div>
          <Link to="/gallery.html" className="inline-flex items-center gap-2 font-head text-sm uppercase tracking-[0.14em] text-muted-foreground transition hover:text-primary">
            Вся галерея <Icon name="ArrowRight" size={16} />
          </Link>
        </div>

        <div className="grid auto-rows-[160px] grid-cols-2 gap-2 md:auto-rows-[220px] md:grid-cols-4">
          {items.map((it, i) => (
            <button key={it.src} onClick={() => setIdx(i)} data-reveal="zoom" data-glow style={{ ["--d" as string]: i }}
              className={`group relative overflow-hidden rounded-[10px] bg-card text-left ${spans[i]}`}>
              <img src={it.src} alt={it.title} loading="lazy" className="h-full w-full object-cover transition duration-[1200ms] ease-out group-hover:scale-110 group-hover:rotate-1" />
              <div className="absolute inset-0 bg-gradient-to-t from-hero-shade/80 via-transparent to-transparent opacity-80 transition group-hover:opacity-100" />
              <div className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-2 p-3 md:p-4">
                <div>
                  <p className="font-head text-[10px] uppercase tracking-[0.16em] text-primary">{it.cat}</p>
                  <p className="font-head text-sm md:text-base">{it.title}</p>
                </div>
                <Icon name="Maximize2" size={16} className="shrink-0 opacity-0 transition group-hover:opacity-100" />
              </div>
            </button>
          ))}
        </div>
      </div>
      <Lightbox items={items} index={idx} onChange={setIdx} />
    </section>
  );
}
