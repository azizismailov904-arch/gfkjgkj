import Icon from "@/components/ui/icon";
import { COMPANY } from "@/data/site";
import { useLead } from "@/components/site/LeadDialog";

export default function MobileCallBar() {
  const lead = useLead();
  return (
    <div className="fixed inset-x-3 bottom-3 z-40 flex gap-2 md:hidden">
      <a href={COMPANY.phoneHref} aria-label="Позвонить"
        className="relative grid h-14 w-14 shrink-0 place-items-center rounded-full bg-primary text-primary-foreground shadow-2xl shadow-hero-shade">
        <span className="absolute inset-0 animate-ping rounded-full bg-primary/40" />
        <Icon name="Phone" size={22} className="relative" />
      </a>
      <button onClick={() => lead.open("calc")}
        className="flex h-14 flex-1 items-center justify-center gap-2 rounded-full bg-hero-shade/95 font-head text-sm font-medium text-foreground shadow-2xl backdrop-blur">
        Рассчитать стоимость <Icon name="ArrowRight" size={16} className="text-primary" />
      </button>
    </div>
  );
}
