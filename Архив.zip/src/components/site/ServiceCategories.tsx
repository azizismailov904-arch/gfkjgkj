import { Link } from "@tanstack/react-router";
import Icon from "@/components/ui/icon";
import { CATEGORIES } from "@/data/services";

export default function ServiceCategories() {
  return (
    <section id="services" className="px-3 py-20 sm:px-5 md:py-28">
      <div className="mx-auto max-w-[1400px]">
        <div data-reveal className="mb-10 flex flex-wrap items-end justify-between gap-6 md:mb-14">
          <div>
            <p className="eyebrow mb-4">02 — Услуги</p>
            <h2 className="section-title">Что делаем<br />на высоте</h2>
          </div>
          <Link to="/uslugi.html" className="inline-flex items-center gap-2 font-head text-sm uppercase tracking-[0.14em] text-muted-foreground transition hover:text-primary">
            Все услуги <Icon name="ArrowRight" size={16} />
          </Link>
        </div>

        <div className="grid gap-2 md:grid-cols-6">
          {CATEGORIES.map((c, i) => (
            <Link key={c.slug} to="/{$slug}.html" params={{ slug: c.slug }} data-reveal data-glow style={{ ["--d" as string]: i }}
              className={`tile group relative flex min-h-[340px] flex-col overflow-hidden ${i < 2 ? "md:col-span-3" : "md:col-span-2"}`}>
              <img src={c.image} alt={c.title} loading="lazy"
                className="absolute inset-0 h-full w-full object-cover opacity-50 transition duration-[1200ms] ease-out group-hover:scale-110 group-hover:opacity-80" />
              <div className="absolute inset-0 bg-gradient-to-t from-card via-card/70 to-card/10" />
              <div className="relative flex items-start justify-between p-5">
                <span className="grid h-11 w-11 place-items-center rounded-full bg-hero-shade/80 text-primary backdrop-blur">
                  <Icon name={c.icon} size={20} />
                </span>
                <span className="font-head text-xs text-muted-foreground">{c.services.length} {c.services.length > 4 ? "услуг" : "услуги"}</span>
              </div>
              <div className="relative mt-auto p-5 md:p-6">
                <h3 className="font-head text-2xl font-normal uppercase tracking-[0.04em] md:text-3xl">{c.title}</h3>
                <p className="mt-2 max-w-md text-sm text-muted-foreground">{c.lead}</p>
                <ul className="mt-4 flex flex-wrap gap-1.5">
                  {c.services.slice(0, 4).map((s) => (
                    <li key={s.slug} className="rounded-full bg-hero-pill/30 px-3 py-1 font-head text-xs">{s.title}</li>
                  ))}
                  {c.services.length > 4 && <li className="rounded-full px-3 py-1 font-head text-xs text-primary">+ ещё {c.services.length - 4}</li>}
                </ul>
              </div>
              <Icon name="ArrowUpRight" size={22} className="absolute bottom-5 right-5 text-primary opacity-0 transition group-hover:opacity-100" />
            </Link>
          ))}
          <Link to="/mastika-tektor.html" data-reveal data-glow
            className="tile group relative flex min-h-[200px] overflow-hidden flex-col justify-between bg-primary p-6 text-primary-foreground md:col-span-6 md:flex-row md:items-end">
            <div>
              <p className="font-head text-xs uppercase tracking-[0.18em] opacity-70">Ведущий поставщик в Белгороде</p>
              <h3 className="mt-3 font-head text-3xl font-normal uppercase tracking-[0.04em] md:text-5xl">Мастика ТЭКТОР®</h3>
            </div>
            <p className="mt-4 max-w-md font-head md:text-right">
              Двухкомпонентный полиуретановый герметик для межпанельных швов. Продаём и наносим.
              <Icon name="ArrowRight" size={20} className="ml-2 inline transition group-hover:translate-x-1" />
            </p>
          </Link>
        </div>
      </div>
    </section>
  );
}
