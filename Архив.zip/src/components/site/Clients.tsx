import { CLIENTS, CLIENT_NAMES } from "@/data/site";

export default function Clients() {
  const loop = [...CLIENTS, ...CLIENTS];
  return (
    <section id="clients" className="overflow-hidden border-y border-border bg-card/70 py-20 backdrop-blur-md md:py-24">
      <div data-reveal className="mx-auto mb-10 grid max-w-[1400px] gap-6 px-3 sm:px-5 md:grid-cols-[1fr_1fr] md:items-end">
        <div>
          <p className="eyebrow mb-4">03 — Нам доверяют</p>
          <h2 className="section-title">БелГУ, «Амакс»,<br />УК и ТСЖ города</h2>
        </div>
        <p className="max-w-md text-muted-foreground md:justify-self-end">
          Работаем с государственными учреждениями, управляющими компаниями, ТСЖ, бизнесом и частными клиентами. У нас десятки благодарственных писем.
        </p>
      </div>

      <div className="group relative">
        <div className="pointer-events-none absolute inset-y-0 left-0 z-10 w-16 bg-gradient-to-r from-card/90 to-transparent md:w-40" />
        <div className="pointer-events-none absolute inset-y-0 right-0 z-10 w-16 bg-gradient-to-l from-card/90 to-transparent md:w-40" />
        <div className="flex w-max animate-marquee gap-3 group-hover:[animation-play-state:paused]">
          {loop.map((c, i) => (
            <div key={i} className="grid h-28 w-52 shrink-0 place-items-center overflow-hidden rounded-[10px] bg-foreground p-3 grayscale transition duration-500 hover:scale-105 hover:grayscale-0 md:h-32 md:w-60">
              <img src={c.logo} alt={c.name} loading="lazy" className="max-h-full max-w-full object-contain" />
            </div>
          ))}
        </div>
      </div>

      <div data-reveal className="mx-auto mt-8 flex max-w-[1400px] flex-wrap gap-2 px-3 sm:px-5">
        {CLIENT_NAMES.map((n) => (
          <span key={n} className="rounded-full border border-border px-4 py-2 font-head text-sm text-muted-foreground">{n}</span>
        ))}
        <span className="rounded-full px-4 py-2 font-head text-sm text-primary">и другие</span>
      </div>
    </section>
  );
}
