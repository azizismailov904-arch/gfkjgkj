import { Link } from "@tanstack/react-router";
import Icon from "@/components/ui/icon";
import { findService } from "@/data/services";

const ITEMS = [
  { slug: "germetizatsiya-mezhpanelnykh-shvov", icon: "PanelsTopLeft" },
  { slug: "pokraska-fasadov", icon: "PaintRoller" },
  { slug: "moyka-okon-fasadov", icon: "Sparkles" },
  { slug: "udalenie-sosulek-uborka-snega", icon: "Snowflake" },
  { slug: "montazh-demontazh-reklamnykh-bannerov", icon: "Megaphone" },
  { slug: "remont-myagkoy-krovli", icon: "House" },
];

export default function ServiceTicker() {
  const items = ITEMS.map((it) => ({ ...it, service: findService(it.slug)?.service })).filter((it) => it.service);

  return (
    <section className="relative px-3 py-10 sm:px-5 md:py-14">
      <div data-reveal className="mx-auto max-w-[1400px] rounded-[10px] border border-border bg-card/80 p-2 backdrop-blur-md">
        <div className="flex flex-wrap items-center justify-between gap-3 px-3 pb-3 pt-2 md:px-4">
          <p className="eyebrow">Популярные услуги</p>
          <Link to="/prise.html" className="inline-flex items-center gap-1.5 font-head text-xs uppercase tracking-[0.14em] text-muted-foreground transition hover:text-primary">
            Весь прайс <Icon name="ArrowRight" size={14} />
          </Link>
        </div>
        <div className="grid grid-cols-2 gap-2 md:grid-cols-3 xl:grid-cols-6">
          {items.map((it, i) => (
            <Link key={it.slug} to="/{$slug}.html" params={{ slug: it.slug }} data-reveal data-glow style={{ ["--d" as string]: i }}
              className="group flex min-h-[150px] flex-col justify-between rounded-md bg-background/70 p-4 transition duration-500 hover:-translate-y-1 hover:bg-secondary">
              <div className="flex items-start justify-between">
                <span className="grid h-10 w-10 place-items-center rounded-full bg-primary/15 text-primary transition duration-500 group-hover:bg-primary group-hover:text-primary-foreground">
                  <Icon name={it.icon} size={18} fallback="Wrench" />
                </span>
                <Icon name="ArrowUpRight" size={18} className="text-muted-foreground transition group-hover:text-primary" />
              </div>
              <div>
                <p className="font-head text-base leading-tight">{it.service!.title}</p>
                {it.service!.priceFrom && <p className="mt-1.5 font-head text-sm text-primary">{it.service!.priceFrom}</p>}
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
