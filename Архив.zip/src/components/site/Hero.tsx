import { Link } from "@tanstack/react-router";
import { COMPANY, HERO_IMAGE } from "@/data/site";
import { useLead } from "@/components/site/LeadDialog";

const photo = (src: string, pos: string) => ({
  backgroundImage: `url(${src})`,
  backgroundPosition: pos,
  backgroundSize: "cover",
  backgroundRepeat: "no-repeat",
});

const SPARKS = [
  { x: 8, t: 14, d: 0, dx: 40 }, { x: 18, t: 18, d: 3, dx: -30 }, { x: 27, t: 12, d: 6, dx: 20 },
  { x: 36, t: 20, d: 1.5, dx: -50 }, { x: 45, t: 16, d: 8, dx: 35 }, { x: 54, t: 13, d: 4.5, dx: -20 },
  { x: 63, t: 19, d: 2, dx: 45 }, { x: 71, t: 15, d: 7, dx: -35 }, { x: 80, t: 17, d: 0.8, dx: 25 },
  { x: 88, t: 12, d: 5.5, dx: -40 }, { x: 94, t: 21, d: 9, dx: 15 }, { x: 4, t: 16, d: 10, dx: 30 },
];

export default function Hero() {
  const lead = useLead();

  return (
    <section
      className="hero-stage relative flex min-h-[100svh] w-full flex-col justify-end overflow-hidden bg-background text-[15px] lg:block lg:h-screen lg:min-h-[800px]"
    >
      <div className="hero-parallax" aria-hidden>
        <div className="hero-photo" style={{ backgroundImage: `url(${HERO_IMAGE})` }} />
      </div>
      <div className="hero-sweep" aria-hidden />
      <div aria-hidden className="pointer-events-none absolute inset-0 z-[1] overflow-hidden">
        {SPARKS.map((s, i) => (
          <span key={i} className="spark"
            style={{ left: `${s.x}%`, animationDuration: `${s.t}s`, animationDelay: `${s.d}s`, ["--dx" as string]: `${s.dx}px` }} />
        ))}
        <span className="rope left-[62%] hidden h-[38%] md:block" />
        <span className="rope left-[78%] h-[22%] opacity-60" style={{ animationDelay: "0.4s, 2.8s" }} />
      </div>

      {/* rule + lead */}
      <div className="absolute left-0 right-0 top-[44%] z-[1] hidden h-px origin-left animate-line-grow bg-foreground/[0.18] lg:top-[376px] lg:block" />
      <p className="relative z-[1] mx-5 mt-28 max-w-[290px] animate-rise text-[1em] leading-[1.38] lg:absolute lg:left-5 lg:top-[396px] lg:m-0 lg:w-[290px]"
        style={{ animationDelay: "0.15s" }}>
        ООО «БелСтройВысоты» — промышленные альпинисты. Работаем на фасадах Белгорода и области без лесов и спецтехники.
      </p>

      <div className="flex-1 lg:hidden" />

      <div className="relative z-[1] mx-4 mt-6 hidden items-center gap-3 font-head text-xs uppercase tracking-[0.18em] text-foreground/70 lg:absolute lg:bottom-[250px] lg:left-5 lg:m-0 lg:flex">
        <span className="scroll-cue" aria-hidden /> Листайте вниз
      </div>
      <h1 className="relative z-[1] mx-4 mb-6 mt-10 font-head text-[54px] font-light uppercase leading-none tracking-[0.06em] sm:text-[72px] lg:absolute lg:bottom-[30px] lg:left-4 lg:m-0 lg:text-[88px] xl:text-[88px]">
        <span className="hero-word"><span style={{ animationDelay: "0.2s" }}>Высотные</span></span><br />
        <span className="hero-word"><span style={{ animationDelay: "0.4s" }}><span className="text-shimmer">работы</span></span></span>
        <span className="sr-only"> в Белгороде и Белгородской области — промышленный альпинизм</span>
      </h1>

      {/* tiles */}
      <div className="relative z-[1] mx-3 mb-3 grid animate-rise grid-cols-2 gap-2 font-head sm:mx-5 sm:mb-5 sm:max-w-[428px] lg:absolute lg:bottom-5 lg:right-5 lg:m-0 lg:w-[428px]"
        style={{ animationDelay: "0.3s" }}>
        <Link to="/uslugi.html" data-glow
          className="group col-span-2 grid grid-cols-[minmax(0,150px)_1fr] gap-4 rounded-[10px] bg-card/[0.88] p-2 backdrop-blur-sm transition hover:bg-card sm:grid-cols-[205px_1fr]">
          <div className="h-[120px] rounded-md bg-background sm:h-[155px]" style={photo("https://cdn.poehali.dev/projects/0db29b78-1970-47b3-bdf5-7b08eee41c5d/files/ce2c9d84-bf10-4c99-a25e-fafd3e718f47.jpg", "center 30%")} />
          <div className="pr-2">
            <h3 className="my-3.5 flex justify-between text-[0.8em] font-normal sm:my-[14px]">
              Любой сложности <span className="transition group-hover:translate-x-1 group-hover:text-primary">→</span>
            </h3>
            <p className="text-[0.95em] leading-[1.4] text-muted-foreground">
              Фасады, кровля, швы, монтаж и мойка окон — на любой высоте.
            </p>
          </div>
        </Link>

        <div className="flex flex-col gap-2">
          <div className="flex gap-1.5">
            <button onClick={() => lead.open("calc")}
              className="btn-glow whitespace-nowrap rounded-full bg-primary px-3.5 py-2 text-[0.88em] font-medium text-primary-foreground transition hover:brightness-110 max-[380px]:px-3 max-[380px]:text-[0.8em]">
              Рассчитать стоимость
            </button>
          </div>
          <Link to="/contact.html" data-glow className="flex min-h-[150px] flex-1 flex-col justify-between rounded-[10px] bg-card/[0.88] p-4 backdrop-blur-sm transition hover:bg-card">
            <svg viewBox="0 0 120 80" className="mx-auto w-[120px]" aria-hidden>
              <path d="M8 30 L30 12 L58 18 L80 8 L110 22 L104 50 L84 70 L50 66 L22 72 L6 52Z" className="fill-hero-map stroke-background" strokeWidth="1" />
              <circle cx="62" cy="38" r="3.5" className="fill-primary" />
              <circle cx="62" cy="38" r="3.5" className="map-ping fill-primary" />
            </svg>
            <span className="text-[0.95em]">Белгород и область</span>
          </Link>
        </div>

        <div className="flex flex-col gap-2">
          <div className="flex gap-1.5">
            <a href={COMPANY.phoneHref}
              className="whitespace-nowrap rounded-full bg-hero-pill/70 px-3.5 py-2 text-[0.88em] transition hover:bg-hero-pill max-[380px]:px-3 max-[380px]:text-[0.8em]">
              {COMPANY.phone}
            </a>
          </div>
          <Link to="/mastika-tektor.html" data-glow className="relative flex rounded-[10px] bg-card/[0.88] p-2 backdrop-blur-sm transition hover:bg-card">
            <div className="relative flex min-h-[190px] flex-1 items-end overflow-hidden rounded-md bg-background p-3" style={photo("https://cdn.poehali.dev/projects/0db29b78-1970-47b3-bdf5-7b08eee41c5d/files/869f8b40-c243-4e1a-90de-0fbeb842c0da.jpg", "center")}>
              <span className="absolute inset-0 bg-gradient-to-t from-hero-shade/90 via-hero-shade/20 to-transparent" />
              <span className="relative text-[0.95em]">Мастика ТЭКТОР®</span>
            </div>
          </Link>
        </div>
      </div>
    </section>
  );
}