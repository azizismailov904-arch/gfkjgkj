import { useState, type FormEvent } from "react";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectGroup, SelectItem, SelectLabel, SelectTrigger, SelectValue } from "@/components/ui/select";
import Icon from "@/components/ui/icon";
import { CATEGORIES } from "@/data/services";
import { cn } from "@/lib/utils";
import { sendLead } from "@/lib/leads";

type Props = { compact?: boolean; defaultService?: string; onDone?: () => void; className?: string };

const formatPhone = (raw: string) => {
  let d = raw.replace(/\D/g, "");
  if (d.startsWith("8")) d = "7" + d.slice(1);
  if (!d.startsWith("7")) d = "7" + d;
  d = d.slice(0, 11);
  const p = d.slice(1);
  let out = "+7";
  if (p.length) out += " (" + p.slice(0, 3);
  if (p.length >= 3) out += ")";
  if (p.length > 3) out += " " + p.slice(3, 6);
  if (p.length > 6) out += "-" + p.slice(6, 8);
  if (p.length > 8) out += "-" + p.slice(8, 10);
  return out;
};

export default function LeadForm({ compact, defaultService, onDone, className }: Props) {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [service, setService] = useState(defaultService ?? "");
  const [address, setAddress] = useState("");
  const [comment, setComment] = useState("");
  const [files, setFiles] = useState<File[]>([]);
  const [agree, setAgree] = useState(true);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [sending, setSending] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const err: Record<string, string> = {};
    if (name.trim().length < 2) err.name = "Укажите имя";
    if (phone.replace(/\D/g, "").length !== 11) err.phone = "Введите номер полностью";
    if (!agree) err.agree = "Нужно согласие на обработку данных";
    setErrors(err);
    if (Object.keys(err).length) return;
    setSending(true);
    try {
      await sendLead({ name, phone, service, address, comment, source: compact ? "Заказать звонок" : "Рассчитать стоимость" }, files);
      toast.success("Заявка принята", { description: "Перезвоним вам в ближайшее время." });
      setName(""); setPhone(""); setAddress(""); setComment(""); setFiles([]);
      onDone?.();
    } catch {
      toast.error("Не удалось отправить заявку", { description: "Попробуйте ещё раз или позвоните +7 (905) 670-87-17" });
    } finally {
      setSending(false);
    }
  };

  const field = "h-12 rounded-[10px] border-border bg-background/60 font-head text-base placeholder:text-muted-foreground/70 focus-visible:ring-primary";

  return (
    <form onSubmit={submit} className={cn("grid gap-3", className)} noValidate>
      <div className="grid gap-3 sm:grid-cols-2">
        <div>
          <Input className={field} placeholder="Ваше имя" value={name} onChange={(e) => setName(e.target.value)} aria-invalid={!!errors.name} />
          {errors.name && <p className="mt-1 font-head text-xs text-destructive">{errors.name}</p>}
        </div>
        <div>
          <Input className={field} type="tel" inputMode="tel" placeholder="+7 (___) ___-__-__" value={phone}
            onChange={(e) => setPhone(e.target.value ? formatPhone(e.target.value) : "")} aria-invalid={!!errors.phone} />
          {errors.phone && <p className="mt-1 font-head text-xs text-destructive">{errors.phone}</p>}
        </div>
      </div>

      {!compact && (
        <>
          <Select value={service} onValueChange={setService}>
            <SelectTrigger className={field}>
              <SelectValue placeholder="Вид работ" />
            </SelectTrigger>
            <SelectContent className="max-h-80">
              {CATEGORIES.map((c) => (
                <SelectGroup key={c.slug}>
                  <SelectLabel className="font-head text-xs uppercase tracking-widest text-primary">{c.title}</SelectLabel>
                  {c.services.map((s) => (
                    <SelectItem key={s.slug} value={s.title} className="font-head">{s.title}</SelectItem>
                  ))}
                </SelectGroup>
              ))}
              <SelectGroup>
                <SelectLabel className="font-head text-xs uppercase tracking-widest text-primary">Другое</SelectLabel>
                <SelectItem value="Мастика ТЭКТОР®" className="font-head">Мастика ТЭКТОР®</SelectItem>
                <SelectItem value="Другая услуга" className="font-head">Другая услуга</SelectItem>
              </SelectGroup>
            </SelectContent>
          </Select>
          <Input className={field} placeholder="Адрес объекта" value={address} onChange={(e) => setAddress(e.target.value)} />
          <Textarea className="min-h-[96px] rounded-[10px] border-border bg-background/60 font-head text-base placeholder:text-muted-foreground/70"
            placeholder="Комментарий: этажность, площадь, сроки" value={comment} onChange={(e) => setComment(e.target.value)} />
          <label className="flex cursor-pointer items-center gap-3 rounded-[10px] border border-dashed border-border px-4 py-3 font-head text-sm text-muted-foreground transition hover:border-primary hover:text-foreground">
            <Icon name="Camera" size={18} className="text-primary" />
            <span className="flex-1 truncate">
              {files.length ? files.map((f) => f.name).join(", ") : "Прикрепить фото объекта (по желанию)"}
            </span>
            <input type="file" accept="image/*" multiple className="hidden"
              onChange={(e) => setFiles(Array.from(e.target.files ?? []).slice(0, 5))} />
          </label>
        </>
      )}

      <label className="flex items-start gap-3 font-head text-xs leading-relaxed text-muted-foreground">
        <Checkbox checked={agree} onCheckedChange={(v) => setAgree(v === true)} className="mt-0.5 border-muted-foreground data-[state=checked]:border-primary data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground" />
        <span>
          Согласен на обработку персональных данных в соответствии с{" "}
          <a href="/polzovatelskoe-soglashenie.html" className="underline underline-offset-2 hover:text-primary">пользовательским соглашением</a>
        </span>
      </label>
      {errors.agree && <p className="-mt-1 font-head text-xs text-destructive">{errors.agree}</p>}

      <button type="submit" disabled={sending}
        className="mt-1 inline-flex h-13 items-center justify-center gap-2 rounded-full bg-primary px-6 py-4 font-head text-base font-medium text-primary-foreground transition hover:brightness-110 disabled:opacity-60">
        {sending ? <Icon name="Loader2" size={18} className="animate-spin" /> : null}
        {compact ? "Перезвоните мне" : "Отправить заявку"}
        {!sending && <Icon name="ArrowRight" size={18} />}
      </button>
    </form>
  );
}