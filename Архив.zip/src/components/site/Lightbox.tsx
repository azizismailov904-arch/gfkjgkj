import { useEffect } from "react";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import Icon from "@/components/ui/icon";

type Item = { src: string; title: string };
type Props = { items: Item[]; index: number | null; onChange: (i: number | null) => void };

export default function Lightbox({ items, index, onChange }: Props) {
  const open = index !== null;
  const go = (d: number) => index !== null && onChange((index + d + items.length) % items.length);

  useEffect(() => {
    if (!open) return;
    const h = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight") go(1);
      if (e.key === "ArrowLeft") go(-1);
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  });

  const item = index !== null ? items[index] : null;

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onChange(null)}>
      <DialogContent className="max-w-5xl border-border bg-card p-3">
        <DialogTitle className="pr-8 font-head text-base font-normal">{item?.title}</DialogTitle>
        {item && <img src={item.src} alt={item.title} className="max-h-[75vh] w-full rounded-md object-contain" />}
        <div className="flex items-center justify-between font-head text-sm text-muted-foreground">
          <button onClick={() => go(-1)} className="inline-flex items-center gap-1 rounded-full px-3 py-2 hover:text-primary"><Icon name="ArrowLeft" size={16} /> Назад</button>
          <span>{index !== null ? index + 1 : 0} / {items.length}</span>
          <button onClick={() => go(1)} className="inline-flex items-center gap-1 rounded-full px-3 py-2 hover:text-primary">Вперёд <Icon name="ArrowRight" size={16} /></button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
