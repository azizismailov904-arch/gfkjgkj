import Icon from "@/components/ui/icon";
import { ADVANTAGES } from "@/data/site";
import { useLead } from "@/components/site/LeadDialog";

export default function Advantages() {
  const lead = useLead();
  const [first, ...rest] = ADVANTAGES;

  return (
    <section id="advantages" className="px-3 py-20 sm:px-5 md:py-28">
      <div className="mx-auto max-w-[1400px]">
        <div data-reveal className="mb-10 grid gap-6 md:mb-14 md:grid-cols-[1fr_auto] md:items-end">
          <div>
            <p className="eyebrow mb-4">01 — Почему промальп</p>
            <h2 className="section-title">Без лесов.<br />Без вышек. <span className="text-primary">Без ограничений.</span></h2>
          </div>
          <p className="max-w-sm text-muted-foreground">
            Промышленный альпинизм — самый быстрый и экономичный способ добраться до любой точки здания.
          </p>
        </div>

        <div className="grid grid-cols-2 gap-2 md:grid-cols-4">
          <div data-reveal="zoom" data-glow className="tile col-span-2 row-span-2 flex flex-col justify-between overflow-hidden bg-primary p-6 text-primary-foreground md:p-8">
            <Icon name={first.icon} size={36} className="animate-float" />
            <div>
              <p className="font-head text-6xl font-light leading-none md:text-8xl">0 ₽</p>
              <p className="mt-2 font-head text-xl font-medium md:text-2xl">{first.title}</p>
              <p className="mt-2 max-w-sm opacity-80">{first.text}</p>
              <button onClick={() => lead.open("calc")}
                className="mt-6 inline-flex items-center gap-2 rounded-full bg-primary-foreground px-5 py-2.5 font-head text-sm font-medium text-primary transition hover:opacity-90">
                Рассчитать стоимость <Icon name="ArrowRight" size={16} />
              </button>
            </div>
          </div>
          {rest.map((a, i) => (
            <div key={a.title} data-reveal data-glow style={{ ["--d" as string]: i + 1 }}
              className={`tile group flex min-h-[180px] flex-col justify-between bg-card/80 p-5 backdrop-blur-sm transition duration-500 hover:-translate-y-1 hover:bg-secondary md:min-h-[210px] ${i >= 4 ? "col-span-2" : ""}`}>
              <div className="flex items-start justify-between">
                <Icon name={a.icon} size={26} className="text-primary transition duration-500 group-hover:rotate-[-8deg] group-hover:scale-125" />
                <span className="font-head text-xs text-muted-foreground">0{i + 2}</span>
              </div>
              <div>
                <h3 className="font-head text-lg font-medium leading-tight md:text-xl">{a.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{a.text}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}