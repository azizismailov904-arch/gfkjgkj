import { createContext, useCallback, useContext, useState, type ReactNode } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import LeadForm from "@/components/site/LeadForm";

type Mode = "calc" | "call";
type Ctx = { open: (mode?: Mode, service?: string) => void };

const LeadCtx = createContext<Ctx>({ open: () => {} });

export const useLead = () => useContext(LeadCtx);

export function LeadProvider({ children }: { children: ReactNode }) {
  const [isOpen, setOpen] = useState(false);
  const [mode, setMode] = useState<Mode>("calc");
  const [service, setService] = useState<string | undefined>();

  const open = useCallback((m: Mode = "calc", s?: string) => {
    setMode(m);
    setService(s);
    setOpen(true);
  }, []);

  return (
    <LeadCtx.Provider value={{ open }}>
      {children}
      <Dialog open={isOpen} onOpenChange={setOpen}>
        <DialogContent className="max-h-[92vh] overflow-y-auto border-border bg-card sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="font-head text-2xl font-normal uppercase tracking-[0.05em]">
              {mode === "calc" ? "Рассчитать стоимость" : "Заказать звонок"}
            </DialogTitle>
            <DialogDescription>
              {mode === "calc"
                ? "Опишите объект — посчитаем стоимость и перезвоним в течение 15 минут в рабочее время."
                : "Оставьте номер — перезвоним и бесплатно проконсультируем."}
            </DialogDescription>
          </DialogHeader>
          <LeadForm compact={mode === "call"} defaultService={service} onDone={() => setOpen(false)} />
        </DialogContent>
      </Dialog>
    </LeadCtx.Provider>
  );
}
