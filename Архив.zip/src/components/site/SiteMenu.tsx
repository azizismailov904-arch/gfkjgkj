import { Link } from "@tanstack/react-router";
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { useState } from "react";
import Icon from "@/components/ui/icon";
import { COMPANY, NAV } from "@/data/site";
import { useLead } from "@/components/site/LeadDialog";

export default function SiteMenu() {
  const [open, setOpen] = useState(false);
  const lead = useLead();

  return (
    <div className="fixed right-3 top-3 z-50 flex items-center gap-2 md:right-5 md:top-[17px]">
      <a href={COMPANY.phoneHref}
        className="hidden rounded-lg bg-hero-shade/90 px-3.5 py-2 font-head text-sm font-medium tracking-[0.04em] text-foreground backdrop-blur transition hover:text-primary lg:block">
        {COMPANY.phone}
      </a>
      <Sheet open={open} onOpenChange={setOpen}>
        <SheetTrigger asChild>
          <button className="flex items-center gap-[18px] rounded-lg bg-hero-shade/90 px-3.5 py-2 font-head font-medium tracking-[0.06em] text-foreground backdrop-blur transition hover:bg-hero-shade" aria-label="Открыть меню">
            БЕЛСТРОЙВЫСОТЫ
            <i className="block h-[9px] w-[26px] border-y-[1.5px] border-foreground" />
          </button>
        </SheetTrigger>
        <SheetContent side="right" className="flex w-full flex-col border-border bg-card p-0 sm:max-w-md">
          <SheetTitle className="sr-only">Меню</SheetTitle>
          <div className="border-b border-border px-7 pb-6 pt-8">
            <p className="eyebrow">Промышленный альпинизм</p>
            <p className="mt-1 font-head text-2xl tracking-[0.06em]">БЕЛСТРОЙВЫСОТЫ</p>
          </div>
          <nav className="flex-1 overflow-y-auto px-7 py-4">
            {NAV.map((n, i) => (
              <Link key={n.to} to={n.to} onClick={() => setOpen(false)}
                className="group flex items-baseline gap-4 border-b border-border/60 py-3.5 font-head text-2xl font-light uppercase tracking-[0.04em] transition hover:text-primary"
                activeProps={{ className: "text-primary" }} activeOptions={{ exact: true }}>
                <span className="w-6 text-xs text-muted-foreground">{String(i + 1).padStart(2, "0")}</span>
                {n.label}
              </Link>
            ))}
          </nav>
          <div className="grid gap-2 border-t border-border p-7">
            <a href={COMPANY.phoneHref} className="font-head text-2xl hover:text-primary">{COMPANY.phone}</a>
            <a href={COMPANY.phone2Href} className="font-head text-muted-foreground hover:text-primary">{COMPANY.phone2}</a>
            <button onClick={() => { setOpen(false); lead.open("calc"); }}
              className="mt-3 inline-flex items-center justify-center gap-2 rounded-full bg-primary px-6 py-3.5 font-head font-medium text-primary-foreground transition hover:brightness-110">
              Рассчитать стоимость <Icon name="ArrowRight" size={18} />
            </button>
          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
}
