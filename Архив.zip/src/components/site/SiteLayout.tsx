import type { ReactNode } from "react";
import { LeadProvider } from "@/components/site/LeadDialog";
import SiteMenu from "@/components/site/SiteMenu";
import Footer from "@/components/site/Footer";
import MobileCallBar from "@/components/site/MobileCallBar";
import AmbientBackground from "@/components/site/AmbientBackground";
import MotionEffects from "@/components/site/MotionEffects";

export default function SiteLayout({ children }: { children: ReactNode }) {
  return (
    <LeadProvider>
      <AmbientBackground />
      <MotionEffects />
      <SiteMenu />
      <main className="relative">{children}</main>
      <Footer />
      <MobileCallBar />
    </LeadProvider>
  );
}
