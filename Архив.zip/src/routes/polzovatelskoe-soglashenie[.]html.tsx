import { createFileRoute } from "@tanstack/react-router";
import SiteLayout from "@/components/site/SiteLayout";
import PageHero from "@/components/site/PageHero";
import { COMPANY } from "@/data/site";

export const Route = createFileRoute("/polzovatelskoe-soglashenie.html")({
  head: () => ({
    meta: [
      { title: "Пользовательское соглашение и обработка персональных данных | БелСтройВысоты" },
      { name: "description", content: "Согласие на обработку персональных данных при отправке заявки на сайте ООО «БелСтройВысоты»." },
    ],
  }),
  component: Agreement,
});

function Agreement() {
  const p = [
    `Настоящее соглашение регулирует порядок обработки персональных данных пользователей сайта ${COMPANY.legal} (далее — Оператор).`,
    "Отправляя заявку через формы на сайте, пользователь даёт согласие на обработку своих персональных данных: имени, номера телефона, адреса объекта, комментария и прикреплённых фотографий.",
    "Персональные данные обрабатываются исключительно в целях связи с пользователем, расчёта стоимости и оказания услуг. Оператор не передаёт данные третьим лицам, за исключением случаев, предусмотренных законодательством РФ.",
    "Обработка осуществляется в соответствии с Федеральным законом № 152-ФЗ «О персональных данных». Согласие действует до момента его отзыва.",
    `Пользователь вправе отозвать согласие, направив письмо на ${COMPANY.email} или позвонив по телефону ${COMPANY.phone}.`,
  ];
  return (
    <SiteLayout>
      <PageHero title="Пользовательское соглашение" crumbs={[{ label: "Соглашение" }]} />
      <section className="px-3 py-12 sm:px-5 md:py-20">
        <div className="tile mx-auto grid max-w-3xl gap-5 p-6 leading-relaxed md:p-10">
          {p.map((t, i) => <p key={i}><span className="mr-2 font-head text-primary">{i + 1}.</span>{t}</p>)}
          <p className="font-head text-sm text-muted-foreground">{COMPANY.legal}, {COMPANY.address}</p>
        </div>
      </section>
    </SiteLayout>
  );
}
