import { createFileRoute } from "@tanstack/react-router";
import SiteLayout from "@/components/site/SiteLayout";
import PageHero from "@/components/site/PageHero";
import LeadSection from "@/components/site/LeadSection";
import Icon from "@/components/ui/icon";
import { useLead } from "@/components/site/LeadDialog";
import { COMPANY } from "@/data/site";

const TITLE = "Мастика ТЭКТОР® в Белгороде — купить у поставщика | БелСтройВысоты";
const DESC = "ООО «БелСтройВысоты» — ведущий поставщик мастики ТЭКТОР® 202 для герметизации межпанельных швов в Белгороде. Продажа и нанесение.";

export const Route = createFileRoute("/mastika-tektor.html")({
  head: () => ({
    meta: [{ title: TITLE }, { name: "description", content: DESC }, { property: "og:title", content: TITLE }, { property: "og:description", content: DESC }],
    links: [{ rel: "canonical", href: "https://promalp31.ru/mastika-tektor.html" }],
  }),
  component: Tektor,
});

const STEPS = [
  ["Подготовка герметика", "Смешиваем два компонента — густую белую пасту и вязкую жидкость — строго по инструкции."],
  ["Очистка швов", "Удаляем из стыка пыль, грязь и наплывы раствора, при необходимости — старый герметик."],
  ["Нанесение", "Наносим мастику в устье стыка шприцем или шпателем, выравниваем слой толщиной не менее 4 мм."],
  ["Окраска", "Через 48 часов, когда герметик отвердеет, поверхность можно окрашивать в цвет фасада."],
];

const DOCS = [
  "Заключение о долговечности",
  "Свидетельство о гос. регистрации",
  "Свидетельство дилера",
  "Сертификат соответствия",
  "Письмо о применении в зимнее время",
  "Письмо о пожаробезопасности",
];

function Tektor() {
  const lead = useLead();
  return (
    <SiteLayout>
      <PageHero title={<>Мастика<br /><span className="text-primary">ТЭКТОР®</span></>} crumbs={[{ label: "Мастика ТЭКТОР®" }]} image="/works/w01.webp"
        lead="ООО «БелСтройВысоты» — ведущий поставщик мастики ТЭКТОР® в Белгороде. Продаём материал и выполняем герметизацию межпанельных швов под ключ.">
        <div className="mt-8 flex flex-wrap gap-2">
          <button onClick={() => lead.open("calc", "Мастика ТЭКТОР®")} className="rounded-full bg-primary px-6 py-3 font-head font-medium text-primary-foreground hover:brightness-110">Узнать цену и наличие</button>
          <a href={COMPANY.phoneHref} className="rounded-full bg-hero-pill/70 px-6 py-3 font-head hover:bg-hero-pill">{COMPANY.phone}</a>
        </div>
      </PageHero>

      <section className="px-3 py-16 sm:px-5 md:py-24">
        <div className="mx-auto grid max-w-[1400px] gap-2 md:grid-cols-3">
          <div className="tile p-6 md:col-span-2 md:p-10">
            <p className="eyebrow mb-4">О материале</p>
            <p className="text-lg leading-relaxed md:text-xl">
              ТЭКТОР 202 — двухкомпонентная мастика на основе полиуретанового каучука. Защищает стыки панелей от воздуха и влаги. После нанесения переходит из жидкого состояния в твёрдое и становится водостойким, прочным и эластичным материалом с отличной адгезией к бетону.
            </p>
          </div>
          <div className="grid grid-cols-2 gap-2 md:grid-cols-1">
            {[["2", "компонента"], ["4 мм", "минимальный слой"], ["48 ч", "до окраски"]].map(([n, t]) => (
              <div key={t} className="tile p-5 last:col-span-2 md:last:col-span-1">
                <p className="font-head text-4xl font-light text-primary">{n}</p>
                <p className="mt-1 font-head text-sm text-muted-foreground">{t}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="mx-auto mt-16 max-w-[1400px]">
          <h2 className="section-title mb-8">Технология</h2>
          <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
            {STEPS.map(([t, d], i) => (
              <div key={t} className="tile flex min-h-[220px] flex-col justify-between p-6">
                <span className="font-head text-5xl font-light text-primary">0{i + 1}</span>
                <div>
                  <h3 className="font-head text-xl">{t}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">{d}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="mx-auto mt-16 max-w-[1400px]">
          <p className="eyebrow mb-5">Документы на материал</p>
          <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {DOCS.map((d) => (
              <div key={d} className="tile flex items-center gap-4 p-5">
                <Icon name="FileCheck2" size={22} className="text-primary" />
                <span className="font-head">{d}</span>
              </div>
            ))}
          </div>
        </div>
      </section>
      <LeadSection title="Купить мастику ТЭКТОР®" />
    </SiteLayout>
  );
}
