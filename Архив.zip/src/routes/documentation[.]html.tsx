import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import SiteLayout from "@/components/site/SiteLayout";
import PageHero from "@/components/site/PageHero";
import LeadSection from "@/components/site/LeadSection";
import Lightbox from "@/components/site/Lightbox";
import Icon from "@/components/ui/icon";
import { DOCS } from "@/data/gallery";

const TITLE = "Лицензия и допуски СРО на высотные работы | БелСтройВысоты";
const DESC = "Свидетельство СРО, квалификационные аттестаты и удостоверения на работы на высоте ООО «БелСтройВысоты», Белгород.";

export const Route = createFileRoute("/documentation.html")({
  head: () => ({
    meta: [{ title: TITLE }, { name: "description", content: DESC }, { property: "og:title", content: TITLE }, { property: "og:description", content: DESC }],
    links: [{ rel: "canonical", href: "https://promalp31.ru/documentation.html" }],
  }),
  component: Docs,
});

function Docs() {
  const [idx, setIdx] = useState<number | null>(null);
  return (
    <SiteLayout>
      <PageHero title={<>Лицензия<br />и допуски</>} crumbs={[{ label: "Лицензия и допуски" }]}
        lead="Мы — член саморегулируемой организации. Сотрудники аттестованы и имеют допуски к работам на высоте в труднодоступных местах." />
      <section className="px-3 py-12 sm:px-5 md:py-20">
        <div className="mx-auto grid max-w-[1400px] grid-cols-2 gap-2 md:grid-cols-3 lg:grid-cols-5">
          {DOCS.map((d, i) => (
            <button key={d.src} onClick={() => setIdx(i)} className="tile group flex flex-col overflow-hidden p-2 text-left transition hover:bg-secondary">
              <div className="aspect-[3/4] overflow-hidden rounded-md bg-foreground">
                <img src={d.src} alt={d.title} loading="lazy" className="h-full w-full object-cover object-top transition duration-500 group-hover:scale-105" />
              </div>
              <div className="flex flex-1 items-start justify-between gap-2 p-3">
                <p className="font-head text-sm leading-snug">{d.title}</p>
                <Icon name="ZoomIn" size={16} className="shrink-0 text-primary" />
              </div>
            </button>
          ))}
        </div>
      </section>
      <Lightbox items={DOCS} index={idx} onChange={setIdx} />
      <LeadSection />
    </SiteLayout>
  );
}
