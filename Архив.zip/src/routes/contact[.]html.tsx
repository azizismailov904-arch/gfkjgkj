import { createFileRoute } from "@tanstack/react-router";
import SiteLayout from "@/components/site/SiteLayout";
import PageHero from "@/components/site/PageHero";
import LeadForm from "@/components/site/LeadForm";
import Icon from "@/components/ui/icon";
import { COMPANY } from "@/data/site";

const TITLE = "Контакты — промышленные альпинисты в Белгороде | БелСтройВысоты";
const DESC = "Белгород, Промышленный проезд, 3. Телефон +7 (905) 670-87-17. Закажите высотные работы или бесплатную консультацию.";

export const Route = createFileRoute("/contact.html")({
  head: () => ({
    meta: [{ title: TITLE }, { name: "description", content: DESC }, { property: "og:title", content: TITLE }, { property: "og:description", content: DESC }],
    links: [{ rel: "canonical", href: "https://promalp31.ru/contact.html" }],
  }),
  component: Contacts,
});

const MAP = "https://yandex.ru/map-widget/v1/?text=%D0%91%D0%B5%D0%BB%D0%B3%D0%BE%D1%80%D0%BE%D0%B4%2C%20%D0%9F%D1%80%D0%BE%D0%BC%D1%8B%D1%88%D0%BB%D0%B5%D0%BD%D0%BD%D1%8B%D0%B9%20%D0%BF%D1%80%D0%BE%D0%B5%D0%B7%D0%B4%2C%203&z=15";

function Contacts() {
  const items = [
    { icon: "Phone", label: "Основной телефон", value: COMPANY.phone, href: COMPANY.phoneHref, big: true },
    { icon: "PhoneCall", label: "Городской", value: COMPANY.phone2, href: COMPANY.phone2Href },
    { icon: "Mail", label: "Почта", value: COMPANY.email, href: `mailto:${COMPANY.email}` },
    { icon: "MapPin", label: "Адрес", value: COMPANY.address },
  ];
  return (
    <SiteLayout>
      <PageHero title={<>Контакты<span className="text-primary">.</span></>} crumbs={[{ label: "Контакты" }]}
        lead="Звоните, пишите или оставьте заявку — приедем на объект в Белгороде и области." />
      <section className="px-3 py-12 sm:px-5 md:py-20">
        <div className="mx-auto grid max-w-[1400px] gap-2 lg:grid-cols-[1fr_1.2fr]">
          <div className="grid gap-2 sm:grid-cols-2">
            {items.map((it) => {
              const inner = (
                <>
                  <Icon name={it.icon} size={22} className="text-primary" />
                  <div className="mt-6">
                    <p className="eyebrow">{it.label}</p>
                    <p className={`mt-1 font-head ${it.big ? "text-2xl" : "text-lg"}`}>{it.value}</p>
                  </div>
                </>
              );
              return it.href ? (
                <a key={it.label} href={it.href} className={`tile flex flex-col justify-between p-6 transition hover:bg-secondary ${it.big ? "sm:col-span-2" : ""}`}>{inner}</a>
              ) : (
                <div key={it.label} className="tile flex flex-col justify-between p-6">{inner}</div>
              );
            })}
            <div className="tile p-6 sm:col-span-2 md:p-8">
              <p className="mb-5 font-head text-xl">Напишите нам</p>
              <LeadForm />
            </div>
          </div>
          <div className="tile min-h-[420px] overflow-hidden p-2">
            <iframe title="Карта: Белгород, Промышленный проезд, 3" src={MAP} className="h-full min-h-[420px] w-full rounded-md grayscale-[0.6] invert-[0.9] hue-rotate-180" loading="lazy" />
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}
