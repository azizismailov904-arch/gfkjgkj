import { createFileRoute, Link } from "@tanstack/react-router";
import SiteLayout from "@/components/site/SiteLayout";
import PageHero from "@/components/site/PageHero";
import LeadSection from "@/components/site/LeadSection";
import Icon from "@/components/ui/icon";
import { CATEGORIES } from "@/data/services";

const TITLE = "Услуги промышленных альпинистов в Белгороде | БелСтройВысоты";
const DESC = "Фасадные, клининговые, монтажные, кровельные и прочие высотные работы в Белгороде и области. Цены от производителя работ, выезд бесплатно.";

export const Route = createFileRoute("/uslugi.html")({
  head: () => ({
    meta: [{ title: TITLE }, { name: "description", content: DESC }, { property: "og:title", content: TITLE }, { property: "og:description", content: DESC }],
    links: [{ rel: "canonical", href: "https://promalp31.ru/uslugi.html" }],
  }),
  component: Services,
});

function Services() {
  return (
    <SiteLayout>
      <PageHero title={<>Услуги<br />на высоте</>} crumbs={[{ label: "Услуги" }]}
        lead="Пять направлений и более 25 видов работ: от герметизации межпанельных швов до покраски водонапорных башен." />
      <section className="px-3 py-16 sm:px-5 md:py-24">
        <div className="mx-auto grid max-w-[1400px] gap-2">
          {CATEGORIES.map((c, ci) => (
            <div key={c.slug} className="tile grid gap-6 p-5 md:grid-cols-[320px_1fr] md:p-8">
              <div>
                <span className="font-head text-xs text-muted-foreground">0{ci + 1}</span>
                <Link to="/{$slug}.html" params={{ slug: c.slug }} className="group mt-2 flex items-center gap-3">
                  <Icon name={c.icon} size={26} className="text-primary" />
                  <h2 className="font-head text-2xl font-normal uppercase tracking-[0.04em] group-hover:text-primary md:text-3xl">{c.title}</h2>
                </Link>
                <p className="mt-3 text-sm text-muted-foreground">{c.lead}</p>
                <img src={c.image} alt={c.title} loading="lazy" className="mt-5 hidden h-40 w-full rounded-md object-cover md:block" />
              </div>
              <div className="grid gap-px self-start overflow-hidden rounded-[10px] bg-border sm:grid-cols-2">
                {c.services.map((s) => (
                  <Link key={s.slug} to="/{$slug}.html" params={{ slug: s.slug }}
                    className="group flex items-center justify-between gap-4 bg-card p-4 transition hover:bg-secondary">
                    <div>
                      <p className="font-head text-lg leading-tight">{s.title}</p>
                      {s.priceFrom && <p className="mt-1 font-head text-sm text-primary">{s.priceFrom}</p>}
                    </div>
                    <Icon name="ArrowRight" size={18} className="shrink-0 text-muted-foreground transition group-hover:translate-x-1 group-hover:text-primary" />
                  </Link>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>
      <LeadSection />
    </SiteLayout>
  );
}
