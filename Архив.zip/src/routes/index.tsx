import { createFileRoute } from "@tanstack/react-router";
import SiteLayout from "@/components/site/SiteLayout";
import Hero from "@/components/site/Hero";
import Advantages from "@/components/site/Advantages";
import ServiceCategories from "@/components/site/ServiceCategories";
import Clients from "@/components/site/Clients";
import Works from "@/components/site/Works";
import LeadSection from "@/components/site/LeadSection";
import ServiceTicker from "@/components/site/ServiceTicker";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Промышленный альпинизм в Белгороде — высотные работы | БелСтройВысоты" },
      { name: "description", content: "Высотные работы любой сложности в Белгороде и области: фасады, межпанельные швы, кровля, мойка окон, монтаж. Без лесов и спецтехники. Выезд и консультация бесплатно." },
      { property: "og:title", content: "Промышленный альпинизм в Белгороде — БелСтройВысоты" },
      { property: "og:description", content: "Высотные работы любой сложности в Белгороде и области без лесов и спецтехники." },
    ],
    links: [{ rel: "canonical", href: "https://promalp31.ru/" }],
  }),
  component: Index,
});

function Index() {
  return (
    <SiteLayout>
      <Hero />
      <ServiceTicker />
      <Advantages />
      <ServiceCategories />
      <Clients />
      <Works />
      <LeadSection />
    </SiteLayout>
  );
}
