import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import SiteLayout from "@/components/site/SiteLayout";
import PageHero from "@/components/site/PageHero";
import LeadSection from "@/components/site/LeadSection";
import Icon from "@/components/ui/icon";
import { findCategory, findService, type Category, type Service } from "@/data/services";
import { useLead } from "@/components/site/LeadDialog";
import { COMPANY } from "@/data/site";

export const Route = createFileRoute("/{$slug}.html")({
  loader: ({ params }) => {
    const cat = findCategory(params.slug);
    if (cat) return { kind: "category" as const, slug: params.slug, title: cat.title, text: cat.lead };
    const s = findService(params.slug);
    if (s) return { kind: "service" as const, slug: params.slug, title: s.service.title, text: s.service.short };
    throw notFound();
  },
  head: ({ loaderData }) => {
    const t = loaderData ? `${loaderData.title} в Белгороде — промышленные альпинисты | БелСтройВысоты` : "БелСтройВысоты";
    const d = loaderData ? `${loaderData.title} в Белгороде и области методом промышленного альпинизма. ${loaderData.text} Звоните: ${COMPANY.phone}.` : "";
    return {
      meta: [
        { title: t },
        { name: "description", content: d },
        { property: "og:title", content: t },
        { property: "og:description", content: d },
      ],
      links: loaderData ? [{ rel: "canonical", href: `https://promalp31.ru/${loaderData.slug}.html` }] : [],
    };
  },
  component: SlugPage,
});

function SlugPage() {
  const { slug } = Route.useParams();
  const cat = findCategory(slug);
  if (cat) return <CategoryPage cat={cat} />;
  const found = findService(slug);
  if (!found) return null;
  return <ServicePage category={found.category} service={found.service} />;
}

function CategoryPage({ cat }: { cat: Category }) {
  const lead = useLead();
  return (
    <SiteLayout>
      <PageHero title={<>{cat.title}<span className="text-primary">.</span></>} lead={cat.text} image={cat.image}
        crumbs={[{ label: "Услуги", to: "/uslugi.html" }, { label: cat.title }]}>
        <div className="mt-8 flex flex-wrap gap-2">
          <button onClick={() => lead.open("calc")} className="rounded-full bg-primary px-6 py-3 font-head font-medium text-primary-foreground hover:brightness-110">Рассчитать стоимость</button>
          <a href={COMPANY.phoneHref} className="rounded-full bg-hero-pill/70 px-6 py-3 font-head hover:bg-hero-pill">{COMPANY.phone}</a>
        </div>
      </PageHero>
      <section className="px-3 py-16 sm:px-5 md:py-24">
        <div className="mx-auto grid max-w-[1400px] gap-2 sm:grid-cols-2 lg:grid-cols-3">
          {cat.services.map((s, i) => (
            <Link key={s.slug} to="/{$slug}.html" params={{ slug: s.slug }}
              className="tile group flex min-h-[240px] flex-col justify-between p-6 transition hover:bg-secondary">
              <div className="flex items-start justify-between">
                <span className="font-head text-xs text-muted-foreground">{String(i + 1).padStart(2, "0")}</span>
                <Icon name="ArrowUpRight" size={22} className="text-primary transition group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
              </div>
              <div>
                <h2 className="font-head text-2xl font-normal leading-tight">{s.title}</h2>
                <p className="mt-2 text-sm text-muted-foreground">{s.short}</p>
                {s.priceFrom && <p className="mt-4 inline-block rounded-full bg-primary/15 px-3 py-1 font-head text-sm text-primary">{s.priceFrom}</p>}
              </div>
            </Link>
          ))}
        </div>
      </section>
      <LeadSection title={`Заявка: ${cat.title.toLowerCase()}`} />
    </SiteLayout>
  );
}

function ServicePage({ category, service }: { category: Category; service: Service }) {
  const lead = useLead();
  const others = category.services.filter((s) => s.slug !== service.slug);
  return (
    <SiteLayout>
      <PageHero title={service.title} lead={service.short} image={category.image}
        crumbs={[{ label: "Услуги", to: "/uslugi.html" }, { label: category.title, to: "/{$slug}.html", params: { slug: category.slug } }, { label: service.title }]} />
      <section className="px-3 py-16 sm:px-5 md:py-24">
        <div className="mx-auto grid max-w-[1400px] gap-2 lg:grid-cols-[1.4fr_1fr]">
          <div className="tile p-6 md:p-10">
            <p className="eyebrow mb-4">Об услуге</p>
            <p className="text-lg leading-relaxed md:text-xl">{service.text}</p>
            <div className="mt-10 grid gap-2 sm:grid-cols-3">
              {[
                ["Construction", "Без лесов и вышек"],
                ["Timer", "Старт за 30 минут"],
                ["ShieldCheck", "Допуски и страховка"],
              ].map(([ic, t]) => (
                <div key={t} className="rounded-[10px] bg-secondary p-4">
                  <Icon name={ic} size={22} className="text-primary" />
                  <p className="mt-3 font-head">{t}</p>
                </div>
              ))}
            </div>
          </div>
          <div className="grid gap-2">
            <div className="tile flex flex-col justify-between bg-primary p-6 text-primary-foreground md:p-8">
              <p className="font-head text-xs uppercase tracking-[0.18em] opacity-70">Стоимость</p>
              <p className="mt-4 font-head text-5xl font-light md:text-6xl">{service.priceFrom ?? "по запросу"}</p>
              <p className="mt-2 text-sm opacity-80">Точная цена — после осмотра объекта. Выезд бесплатно.</p>
              <button onClick={() => lead.open("calc", service.title)}
                className="mt-6 inline-flex items-center justify-center gap-2 rounded-full bg-primary-foreground px-6 py-3 font-head font-medium text-primary hover:opacity-90">
                Рассчитать стоимость <Icon name="ArrowRight" size={18} />
              </button>
            </div>
            <Link to="/prise.html" className="tile flex items-center justify-between p-6 font-head transition hover:bg-secondary">
              Смотреть полный прайс <Icon name="ArrowRight" size={18} className="text-primary" />
            </Link>
          </div>
        </div>
        {others.length > 0 && (
          <div className="mx-auto mt-16 max-w-[1400px]">
            <p className="eyebrow mb-5">Ещё в разделе «{category.title}»</p>
            <div className="flex flex-wrap gap-2">
              {others.map((s) => (
                <Link key={s.slug} to="/{$slug}.html" params={{ slug: s.slug }}
                  className="rounded-full border border-border px-4 py-2 font-head text-sm transition hover:border-primary hover:text-primary">{s.title}</Link>
              ))}
            </div>
          </div>
        )}
      </section>
      <LeadSection title={`Заказать: ${service.title.toLowerCase()}`} />
    </SiteLayout>
  );
}
