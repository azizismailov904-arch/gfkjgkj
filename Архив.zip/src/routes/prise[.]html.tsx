import { useEffect, useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import SiteLayout from "@/components/site/SiteLayout";
import PageHero from "@/components/site/PageHero";
import Icon from "@/components/ui/icon";
import { PRICES, type PriceCategory } from "@/data/prices";
import { loadPrices } from "@/lib/store";
import { useLead } from "@/components/site/LeadDialog";
import { COMPANY } from "@/data/site";

const TITLE = "Прайс на высотные работы в Белгороде | БелСтройВысоты";
const DESC = "Полный прайс-лист на высотные работы методом промышленного альпинизма в Белгороде и Белгородской области: фасады, швы, кровля, мойка окон.";

export const Route = createFileRoute("/prise.html")({
  head: () => ({
    meta: [{ title: TITLE }, { name: "description", content: DESC }, { property: "og:title", content: TITLE }, { property: "og:description", content: DESC }],
    links: [{ rel: "canonical", href: "https://promalp31.ru/prise.html" }],
  }),
  component: Prices,
});

function Prices() {
  const lead = useLead();
  const [data, setData] = useState<PriceCategory[]>(PRICES);
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("all");

  useEffect(() => setData(loadPrices()), []);

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    return data
      .filter((c) => cat === "all" || c.slug === cat)
      .map((c) => ({
        ...c,
        groups: c.groups
          .map((g) => {
            if (!s || g.title.toLowerCase().includes(s)) return g;
            return { ...g, rows: g.rows.filter((r) => r.name.toLowerCase().includes(s)) };
          })
          .filter((g) => g.rows.length),
      }))
      .filter((c) => c.groups.length);
  }, [data, q, cat]);

  return (
    <SiteLayout>
      <PageHero title={<>Прайс<span className="text-primary">.</span></>} crumbs={[{ label: "Прайс" }]}
        lead="Цены на высотные работы в Белгороде и области. Указаны минимальные цены «от» — точную стоимость назовём после осмотра объекта." />

      <section className="px-3 py-12 sm:px-5 md:py-20">
        <div className="mx-auto max-w-[1100px]">
          <div className="sticky top-16 z-30 -mx-3 mb-6 grid gap-3 bg-background/90 px-3 py-3 backdrop-blur sm:mx-0 sm:rounded-[10px] md:top-[70px]">
            <div className="relative">
              <Icon name="Search" size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Найти услугу: покраска, швы, сосульки…"
                className="h-12 w-full rounded-[10px] border border-border bg-card pl-11 pr-10 font-head text-base outline-none placeholder:text-muted-foreground/70 focus:border-primary" />
              {q && <button onClick={() => setQ("")} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground" aria-label="Очистить"><Icon name="X" size={18} /></button>}
            </div>
            <div className="-mx-3 flex gap-1.5 overflow-x-auto px-3 pb-1 sm:mx-0 sm:flex-wrap sm:px-0">
              {[{ slug: "all", title: "Все" }, ...data].map((c) => (
                <button key={c.slug} onClick={() => setCat(c.slug)}
                  className={`shrink-0 rounded-full px-4 py-2 font-head text-sm transition ${cat === c.slug ? "bg-primary text-primary-foreground" : "bg-card text-muted-foreground hover:text-foreground"}`}>
                  {c.title}
                </button>
              ))}
            </div>
          </div>

          {filtered.length === 0 && (
            <div className="tile p-10 text-center">
              <p className="font-head text-xl">Ничего не нашли по запросу «{q}»</p>
              <p className="mt-2 text-muted-foreground">Опишите задачу — посчитаем индивидуально.</p>
            </div>
          )}

          <div className="grid gap-10">
            {filtered.map((c) => (
              <div key={c.slug}>
                <h2 className="mb-4 font-head text-2xl font-normal uppercase tracking-[0.05em] md:text-3xl">{c.title}</h2>
                <div className="grid gap-2">
                  {c.groups.map((g) => (
                    <div key={g.title} className="tile overflow-hidden">
                      <div className="flex items-center justify-between gap-4 border-b border-border px-5 py-4">
                        <h3 className="font-head text-lg">{g.title}</h3>
                        <button onClick={() => lead.open("calc", undefined)} className="hidden shrink-0 font-head text-xs uppercase tracking-[0.14em] text-primary hover:underline sm:block">Заказать</button>
                      </div>
                      <ul>
                        {g.rows.map((r) => (
                          <li key={r.name} className="flex items-baseline justify-between gap-4 border-b border-border/50 px-5 py-3 last:border-0 hover:bg-secondary/50">
                            <span className="text-sm md:text-base">{r.name}</span>
                            <span className="flex-1 translate-y-[-4px] border-b border-dotted border-border" />
                            <span className="shrink-0 whitespace-nowrap font-head text-base font-medium text-primary md:text-lg">
                              {r.price}{/^\D*\d/.test(r.price) ? " ₽" : ""}
                            </span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>

          <div className="tile mt-12 grid gap-6 bg-primary p-6 text-primary-foreground md:grid-cols-[1fr_auto] md:items-center md:p-10">
            <div>
              <p className="font-head text-2xl md:text-3xl">Не нашли нужную услугу?</p>
              <p className="mt-2 opacity-80">Оставьте заявку или позвоните — выполним любую работу на высоте и посчитаем индивидуально.</p>
            </div>
            <div className="flex flex-wrap gap-2">
              <button onClick={() => lead.open("calc")} className="rounded-full bg-primary-foreground px-6 py-3 font-head font-medium text-primary hover:opacity-90">Оставить заявку</button>
              <a href={COMPANY.phoneHref} className="rounded-full border border-primary-foreground/40 px-6 py-3 font-head hover:bg-primary-foreground/10">{COMPANY.phone}</a>
            </div>
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}
