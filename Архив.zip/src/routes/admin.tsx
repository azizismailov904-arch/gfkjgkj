import { useCallback, useEffect, useState, type FormEvent } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Icon from "@/components/ui/icon";
import { loadPrices, resetPrices, savePrices } from "@/lib/store";
import { adminLogin, deleteLead, fetchLeads, updateLeadStatus, type Lead } from "@/lib/leads";
import { PRICES, type PriceCategory } from "@/data/prices";

export const Route = createFileRoute("/admin")({
  ssr: false,
  head: () => ({ meta: [{ title: "Админка — БелСтройВысоты" }, { name: "robots", content: "noindex" }] }),
  component: Admin,
});

const AUTH_KEY = "bsv_admin_pass";

const STATUS: Record<Lead["status"], { label: string; cls: string }> = {
  new: { label: "Новая", cls: "bg-primary text-primary-foreground" },
  work: { label: "В работе", cls: "bg-hero-pill text-foreground" },
  done: { label: "Закрыта", cls: "bg-secondary text-muted-foreground" },
};

function Admin() {
  const [token, setToken] = useState("");
  const [pass, setPass] = useState("");
  const [checking, setChecking] = useState(false);

  useEffect(() => setToken(sessionStorage.getItem(AUTH_KEY) || ""), []);

  const logout = () => { sessionStorage.removeItem(AUTH_KEY); setToken(""); };

  const login = async (e: FormEvent) => {
    e.preventDefault();
    setChecking(true);
    try {
      await adminLogin(pass);
      sessionStorage.setItem(AUTH_KEY, pass);
      setToken(pass);
      setPass("");
    } catch {
      toast.error("Неверный пароль");
    } finally {
      setChecking(false);
    }
  };

  if (!token) {
    return (
      <div className="dots grid min-h-screen place-items-center px-4">
        <form onSubmit={login} className="tile w-full max-w-sm p-8">
          <p className="eyebrow">БелСтройВысоты</p>
          <h1 className="mt-2 font-head text-3xl font-light uppercase tracking-[0.05em]">Вход</h1>
          <input type="password" value={pass} onChange={(e) => setPass(e.target.value)} placeholder="Пароль"
            className="mt-6 h-12 w-full rounded-[10px] border border-border bg-background px-4 font-head outline-none focus:border-primary" />
          <button disabled={checking || !pass} className="mt-3 h-12 w-full rounded-full bg-primary font-head font-medium text-primary-foreground hover:brightness-110 disabled:opacity-60">{checking ? "Проверяю…" : "Войти"}</button>
          <Link to="/" className="mt-6 inline-flex items-center gap-1 font-head text-sm text-muted-foreground hover:text-primary"><Icon name="ArrowLeft" size={14} /> На сайт</Link>
        </form>
      </div>
    );
  }

  return (
    <div className="min-h-screen px-3 py-6 sm:px-6">
      <div className="mx-auto max-w-6xl">
        <header className="mb-6 flex flex-wrap items-center justify-between gap-3">
          <div>
            <p className="eyebrow">Панель управления</p>
            <h1 className="font-head text-3xl font-light uppercase tracking-[0.05em]">БелСтройВысоты</h1>
          </div>
          <div className="flex gap-2 font-head text-sm">
            <Link to="/" className="rounded-full bg-card px-4 py-2 hover:text-primary">На сайт</Link>
            <button onClick={logout} className="rounded-full bg-card px-4 py-2 hover:text-primary">Выйти</button>
          </div>
        </header>
        <Tabs defaultValue="leads">
          <TabsList className="mb-4 bg-card">
            <TabsTrigger value="leads" className="font-head data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">Заявки</TabsTrigger>
            <TabsTrigger value="prices" className="font-head data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">Прайс</TabsTrigger>
          </TabsList>
          <TabsContent value="leads"><LeadsTab token={token} onUnauthorized={logout} /></TabsContent>
          <TabsContent value="prices"><PricesTab /></TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

function LeadsTab({ token, onUnauthorized }: { token: string; onUnauthorized: () => void }) {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<"all" | Lead["status"]>("all");

  const handleError = useCallback((e: unknown) => {
    if (e instanceof Error && e.message === "unauthorized") onUnauthorized();
    else toast.error("Не удалось связаться с сервером");
  }, [onUnauthorized]);

  const reload = useCallback(async () => {
    setLoading(true);
    try { setLeads(await fetchLeads(token)); } catch (e) { handleError(e); } finally { setLoading(false); }
  }, [token, handleError]);

  useEffect(() => { reload(); }, [reload]);

  const shown = filter === "all" ? leads : leads.filter((l) => l.status === filter);
  const setStatus = async (id: number, status: Lead["status"]) => {
    try {
      await updateLeadStatus(token, id, status);
      setLeads((all) => all.map((l) => (l.id === id ? { ...l, status } : l)));
    } catch (e) { handleError(e); }
  };
  const remove = async (id: number) => {
    if (!confirm("Удалить заявку?")) return;
    try {
      await deleteLead(token, id);
      setLeads((all) => all.filter((x) => x.id !== id));
    } catch (e) { handleError(e); }
  };

  return (
    <div>
      <div className="mb-4 flex flex-wrap gap-1.5">
        <button onClick={reload} className="inline-flex items-center gap-1.5 rounded-full bg-card px-4 py-2 font-head text-sm text-muted-foreground hover:text-primary">
          <Icon name="RefreshCw" size={14} className={loading ? "animate-spin" : ""} /> Обновить
        </button>
        {(["all", "new", "work", "done"] as const).map((s) => (
          <button key={s} onClick={() => setFilter(s)}
            className={`rounded-full px-4 py-2 font-head text-sm ${filter === s ? "bg-primary text-primary-foreground" : "bg-card text-muted-foreground"}`}>
            {s === "all" ? "Все" : STATUS[s].label} <span className="opacity-60">{s === "all" ? leads.length : leads.filter((l) => l.status === s).length}</span>
          </button>
        ))}
      </div>
      {loading && leads.length === 0 ? (
        <div className="tile p-10 text-center font-head text-muted-foreground">Загружаю заявки…</div>
      ) : shown.length === 0 ? (
        <div className="tile p-10 text-center">
          <Icon name="Inbox" size={32} className="mx-auto text-muted-foreground" />
          <p className="mt-3 font-head">Заявок пока нет</p>
          <p className="mt-1 text-sm text-muted-foreground">Отправьте заявку с сайта — она появится здесь.</p>
        </div>
      ) : (
        <div className="grid gap-2">
          {shown.map((l) => (
            <div key={l.id} className="tile grid gap-3 p-5 md:grid-cols-[1fr_auto]">
              <div>
                <div className="flex flex-wrap items-center gap-3">
                  <span className={`rounded-full px-3 py-0.5 font-head text-xs ${STATUS[l.status].cls}`}>{STATUS[l.status].label}</span>
                  <span className="font-head text-xs text-muted-foreground">{new Date(l.created_at).toLocaleString("ru-RU")}</span>
                  {l.source && <span className="font-head text-xs text-muted-foreground">· {l.source}</span>}
                </div>
                <p className="mt-2 font-head text-xl">{l.name} · <a href={`tel:${l.phone.replace(/\D/g, "")}`} className="text-primary">{l.phone}</a></p>
                <div className="mt-1 grid gap-0.5 text-sm text-muted-foreground">
                  {l.service && <p>Вид работ: {l.service}</p>}
                  {l.address && <p>Адрес: {l.address}</p>}
                  {l.comment && <p>Комментарий: {l.comment}</p>}
                </div>
                {l.photos.length > 0 && (
                  <div className="mt-3 flex flex-wrap gap-2">
                    {l.photos.map((src) => (
                      <a key={src} href={src} target="_blank" rel="noreferrer" className="block h-20 w-20 overflow-hidden rounded-md border border-border hover:border-primary">
                        <img src={src} alt="Фото объекта" className="h-full w-full object-cover" />
                      </a>
                    ))}
                  </div>
                )}
              </div>
              <div className="flex flex-wrap items-start gap-1.5">
                {(["new", "work", "done"] as const).map((s) => (
                  <button key={s} onClick={() => setStatus(l.id, s)} disabled={l.status === s}
                    className="rounded-full border border-border px-3 py-1.5 font-head text-xs hover:border-primary disabled:opacity-40">{STATUS[s].label}</button>
                ))}
                <button onClick={() => remove(l.id)} className="rounded-full px-2 py-1.5 text-muted-foreground hover:text-destructive" aria-label="Удалить">
                  <Icon name="Trash2" size={16} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function PricesTab() {
  const [data, setData] = useState<PriceCategory[]>(PRICES);
  useEffect(() => setData(loadPrices()), []);

  const update = (ci: number, gi: number, ri: number, key: "name" | "price", v: string) =>
    setData((d) => d.map((c, i) => i !== ci ? c : {
      ...c, groups: c.groups.map((g, j) => j !== gi ? g : { ...g, rows: g.rows.map((r, k) => k !== ri ? r : { ...r, [key]: v }) }),
    }));
  const addRow = (ci: number, gi: number) =>
    setData((d) => d.map((c, i) => i !== ci ? c : { ...c, groups: c.groups.map((g, j) => j !== gi ? g : { ...g, rows: [...g.rows, { name: "Новая позиция", price: "от 0" }] }) }));
  const delRow = (ci: number, gi: number, ri: number) =>
    setData((d) => d.map((c, i) => i !== ci ? c : { ...c, groups: c.groups.map((g, j) => j !== gi ? g : { ...g, rows: g.rows.filter((_, k) => k !== ri) }) }));

  return (
    <div>
      <div className="sticky top-0 z-10 mb-4 flex flex-wrap gap-2 bg-background/90 py-3 backdrop-blur">
        <button onClick={() => { savePrices(data); toast.success("Прайс сохранён"); }} className="rounded-full bg-primary px-5 py-2.5 font-head text-sm font-medium text-primary-foreground">Сохранить прайс</button>
        <button onClick={() => { resetPrices(); setData(PRICES); toast("Прайс сброшен к исходному"); }} className="rounded-full bg-card px-5 py-2.5 font-head text-sm">Сбросить</button>
      </div>
      <div className="grid gap-6">
        {data.map((c, ci) => (
          <div key={c.slug}>
            <h2 className="mb-3 font-head text-xl uppercase tracking-[0.05em]">{c.title}</h2>
            <div className="grid gap-2">
              {c.groups.map((g, gi) => (
                <div key={g.title} className="tile p-4">
                  <div className="mb-2 flex items-center justify-between">
                    <p className="font-head text-primary">{g.title}</p>
                    <button onClick={() => addRow(ci, gi)} className="inline-flex items-center gap-1 font-head text-xs text-muted-foreground hover:text-primary"><Icon name="Plus" size={14} /> Строка</button>
                  </div>
                  <div className="grid gap-1.5">
                    {g.rows.map((r, ri) => (
                      <div key={ri} className="grid grid-cols-[1fr_110px_auto] gap-1.5">
                        <input value={r.name} onChange={(e) => update(ci, gi, ri, "name", e.target.value)} className="h-10 min-w-0 rounded-md border border-border bg-background px-3 text-sm outline-none focus:border-primary" />
                        <input value={r.price} onChange={(e) => update(ci, gi, ri, "price", e.target.value)} className="h-10 min-w-0 rounded-md border border-border bg-background px-3 font-head text-sm outline-none focus:border-primary" />
                        <button onClick={() => delRow(ci, gi, ri)} className="px-2 text-muted-foreground hover:text-destructive" aria-label="Удалить"><Icon name="X" size={16} /></button>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}