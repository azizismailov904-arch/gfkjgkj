import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import SiteLayout from "@/components/site/SiteLayout";
import PageHero from "@/components/site/PageHero";
import LeadSection from "@/components/site/LeadSection";
import Lightbox from "@/components/site/Lightbox";
import Icon from "@/components/ui/icon";
import { GALLERY, GALLERY_CATS } from "@/data/gallery";

const TITLE = "Фотогалерея высотных работ в Белгороде | БелСтройВысоты";
const DESC = "Фото объектов промышленных альпинистов «БелСтройВысоты»: межпанельные швы, фасады, мосты и путепроводы, дымовые трубы.";

export const Route = createFileRoute("/gallery.html")({
  head: () => ({
    meta: [{ title: TITLE }, { name: "description", content: DESC }, { property: "og:title", content: TITLE }, { property: "og:description", content: DESC }],
    links: [{ rel: "canonical", href: "https://promalp31.ru/gallery.html" }],
  }),
  component: Gallery,
});

function Gallery() {
  const [cat, setCat] = useState<string>("Все");
  const [idx, setIdx] = useState<number | null>(null);
  const items = cat === "Все" ? GALLERY : GALLERY.filter((g) => g.cat === cat);

  return (
    <SiteLayout>
      <PageHero title={<>Наши<br />объекты</>} crumbs={[{ label: "Фотогалерея" }]} image="/works/w25.webp"
        lead="Реальные фото с объектов в Белгороде и области. Выберите вид работ, чтобы отфильтровать." />
      <section className="px-3 py-12 sm:px-5 md:py-20">
        <div className="mx-auto max-w-[1400px]">
          <div className="-mx-3 mb-6 flex gap-1.5 overflow-x-auto px-3 pb-1 sm:mx-0 sm:flex-wrap sm:px-0">
            {GALLERY_CATS.map((c) => {
              const n = c === "Все" ? GALLERY.length : GALLERY.filter((g) => g.cat === c).length;
              return (
                <button key={c} onClick={() => setCat(c)}
                  className={`shrink-0 rounded-full px-4 py-2 font-head text-sm transition ${cat === c ? "bg-primary text-primary-foreground" : "bg-card text-muted-foreground hover:text-foreground"}`}>
                  {c} <span className="opacity-60">{n}</span>
                </button>
              );
            })}
          </div>
          <div className="columns-2 gap-2 md:columns-3 lg:columns-4">
            {items.map((it, i) => (
              <button key={it.src} onClick={() => setIdx(i)}
                className="group relative mb-2 block w-full overflow-hidden rounded-[10px] bg-card text-left animate-in fade-in duration-500">
                <img src={it.src} alt={it.title} loading="lazy" className="w-full transition duration-700 group-hover:scale-105" />
                <div className="absolute inset-0 flex items-end bg-gradient-to-t from-hero-shade/80 to-transparent p-3 opacity-0 transition group-hover:opacity-100">
                  <div className="flex w-full items-end justify-between gap-2">
                    <p className="font-head text-sm">{it.title}</p>
                    <Icon name="Maximize2" size={16} />
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      </section>
      <Lightbox items={items} index={idx} onChange={setIdx} />
      <LeadSection />
    </SiteLayout>
  );
}
