import func2url from "../../backend/func2url.json";

const API = (func2url as Record<string, string>).leads;

export type Lead = {
  id: number;
  created_at: string;
  name: string;
  phone: string;
  service?: string;
  address?: string;
  comment?: string;
  photos: string[];
  source?: string;
  status: "new" | "work" | "done";
};

export type NewLead = {
  name: string;
  phone: string;
  service?: string;
  address?: string;
  comment?: string;
  source?: string;
};

const fileToPhoto = (file: File) =>
  new Promise<{ data: string; type: string }>((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      const max = 1600;
      const k = Math.min(1, max / Math.max(img.width, img.height));
      const canvas = document.createElement("canvas");
      canvas.width = Math.round(img.width * k);
      canvas.height = Math.round(img.height * k);
      canvas.getContext("2d")!.drawImage(img, 0, 0, canvas.width, canvas.height);
      URL.revokeObjectURL(url);
      resolve({ data: canvas.toDataURL("image/jpeg", 0.82), type: "image/jpeg" });
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("Не удалось прочитать фото"));
    };
    img.src = url;
  });


export async function sendLead(lead: NewLead, files: File[] = []) {
  const photos = await Promise.all(files.slice(0, 5).map(fileToPhoto));
  const res = await fetch(API, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ ...lead, photos }),
  });
  if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || "Не удалось отправить заявку");
}

const adminFetch = async (password: string, path: string, init: RequestInit = {}) => {
  const res = await fetch(API + path, {
    ...init,
    headers: { "Content-Type": "application/json", "X-Admin-Password": password, ...(init.headers || {}) },
  });
  if (res.status === 401) throw new Error("unauthorized");
  if (!res.ok) throw new Error("Ошибка сервера");
  return res.json();
};

export const adminLogin = (password: string) => adminFetch(password, "?action=login", { method: "POST", body: "{}" });
export const fetchLeads = async (password: string): Promise<Lead[]> => (await adminFetch(password, "")).leads;
export const updateLeadStatus = (password: string, id: number, status: Lead["status"]) =>
  adminFetch(password, `?id=${id}`, { method: "PUT", body: JSON.stringify({ status }) });
export const deleteLead = (password: string, id: number) => adminFetch(password, `?id=${id}`, { method: "DELETE" });
