import { PRICES, type PriceCategory } from "@/data/prices";

const PRICES_KEY = "bsv_prices";

export const loadPrices = (): PriceCategory[] => {
  try {
    const raw = localStorage.getItem(PRICES_KEY);
    return raw ? JSON.parse(raw) : PRICES;
  } catch {
    return PRICES;
  }
};

export const savePrices = (p: PriceCategory[]) => localStorage.setItem(PRICES_KEY, JSON.stringify(p));
export const resetPrices = () => localStorage.removeItem(PRICES_KEY);
