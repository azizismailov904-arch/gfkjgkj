export const COMPANY = {
  name: "БелСтройВысоты",
  legal: "ООО «БелСтройВысоты»",
  address: "г. Белгород, Промышленный проезд, 3",
  phone: "+7 (905) 670-87-17",
  phoneHref: "tel:+79056708717",
  phone2: "+7 (4722) 41-31-67",
  phone2Href: "tel:+74722413167",
  email: "vash-yra@mail.ru",
  site: "https://promalp31.ru",
};

export const HERO_IMAGE =
  "https://cdn.poehali.dev/projects/0db29b78-1970-47b3-bdf5-7b08eee41c5d/files/7cd22e3f-65bf-4bc8-abca-a2f9eaebe927.jpg";

export const NAV = [
  { to: "/", label: "Главная" },
  { to: "/uslugi.html", label: "Услуги" },
  { to: "/prise.html", label: "Прайс" },
  { to: "/mastika-tektor.html", label: "Мастика ТЭКТОР®" },
  { to: "/gallery.html", label: "Фотогалерея" },
  { to: "/documentation.html", label: "Лицензия и допуски" },
  { to: "/contact.html", label: "Контакты" },
] as const;

export const ADVANTAGES = [
  { icon: "Construction", title: "Без лесов и спецтехники", text: "Не нужны автовышки, люльки и леса — экономия бюджета и времени." },
  { icon: "ArrowUpToLine", title: "Высота не ограничена", text: "Работаем на зданиях любой этажности, трубах, башнях и мостах." },
  { icon: "Timer", title: "Старт через 30 минут", text: "Минимум оборудования — начинаем работу почти сразу после приезда." },
  { icon: "Car", title: "Выезд на объект", text: "Приедем, осмотрим и оценим объём работ по Белгороду и области." },
  { icon: "Users", title: "Не мешаем людям", text: "Без траншей и перекрытий: прохожие и соседние здания не страдают." },
  { icon: "ShieldCheck", title: "По нормам безопасности", text: "Допуски, обвязки, страховка, каски — всё по правилам работ на высоте." },
  { icon: "MessageCircle", title: "Бесплатная консультация", text: "Подскажем технологию и сориентируем по цене по телефону." },
] as const;

export const CLIENTS = [
  { logo: "/clients/c1.webp", name: "БелГУ" },
  { logo: "/clients/c2.webp", name: "Отель «Амакс»" },
  { logo: "/clients/c3.webp", name: "Сокол-АТС" },
  { logo: "/clients/c5.webp", name: "Белая птица" },
  { logo: "/clients/c6.webp", name: "Агро-Белогорье" },
  { logo: "/clients/c4.webp", name: "Детский сад №75" },
  { logo: "/clients/c7.webp", name: "УК по ЖКО-25" },
  { logo: "/clients/c19.webp", name: "УК «Аспект»" },
  { logo: "/clients/c16.webp", name: "ЭКОМИР ЖБК-1" },
  { logo: "/clients/c17.webp", name: "УК п. Майский" },
  { logo: "/clients/c9.webp", name: "Жилищное управление ЖБК-1" },
];

export const CLIENT_NAMES = [
  "ТСЖ «Левобережье»",
  "ТСЖ «Ватутинское»",
  "УК «Центральная»",
  "УО «Молодёжная»",
  "УК по жилью №7",
  "УК «Ремстройэксплуатация»",
  "Аварийная служба г. Белгорода",
  "СП ДСК «Центр»",
  "УК п. Октябрьский",
  "«Коммунальщик» Разумное",
];
