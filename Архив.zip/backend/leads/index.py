import base64
import json
import os
import smtplib
import uuid
from email.mime.text import MIMEText
from email.utils import formataddr

import boto3
import psycopg2

SCHEMA = os.environ.get('MAIN_DB_SCHEMA', 't_p29809016_belstroivysoty')
NOTIFY_EMAIL = 'vash-yra@mail.ru'
STATUSES = ('new', 'work', 'done')
CORS = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, X-Admin-Password',
    'Access-Control-Max-Age': '86400',
}


def resp(code: int, data) -> dict:
    return {'statusCode': code, 'headers': {**CORS, 'Content-Type': 'application/json'},
            'body': json.dumps(data, ensure_ascii=False, default=str)}


def q(s) -> str:
    if s is None:
        return 'NULL'
    return "'" + str(s).replace("'", "''") + "'"


def is_admin(event: dict) -> bool:
    headers = {k.lower(): v for k, v in (event.get('headers') or {}).items()}
    expected = os.environ.get('ADMIN_PASSWORD', '')
    return bool(expected) and headers.get('x-admin-password', '') == expected


def upload_photos(photos: list) -> list:
    if not photos:
        return []
    s3 = boto3.client('s3', endpoint_url='https://bucket.poehali.dev',
                      aws_access_key_id=os.environ['AWS_ACCESS_KEY_ID'],
                      aws_secret_access_key=os.environ['AWS_SECRET_ACCESS_KEY'])
    urls = []
    for p in photos[:5]:
        raw = str(p.get('data', ''))
        if ',' in raw:
            raw = raw.split(',', 1)[1]
        if not raw:
            continue
        ctype = p.get('type') or 'image/jpeg'
        ext = {'image/png': 'png', 'image/webp': 'webp'}.get(ctype, 'jpg')
        key = f'leads/{uuid.uuid4().hex}.{ext}'
        s3.put_object(Bucket='files', Key=key, Body=base64.b64decode(raw), ContentType=ctype)
        urls.append(f"https://cdn.poehali.dev/projects/{os.environ['AWS_ACCESS_KEY_ID']}/bucket/{key}")
    return urls


def send_email(lead: dict) -> None:
    password = os.environ.get('SMTP_PASSWORD')
    if not password:
        return
    lines = [
        f"Имя: {lead['name']}",
        f"Телефон: {lead['phone']}",
        f"Вид работ: {lead.get('service') or '—'}",
        f"Адрес объекта: {lead.get('address') or '—'}",
        f"Комментарий: {lead.get('comment') or '—'}",
    ]
    if lead.get('photos'):
        lines.append('Фото объекта:')
        lines.extend(lead['photos'])
    msg = MIMEText('Новая заявка с сайта БелСтройВысоты\n\n' + '\n'.join(lines), 'plain', 'utf-8')
    msg['Subject'] = f"Новая заявка: {lead['name']}, {lead['phone']}"
    msg['From'] = formataddr(('Сайт БелСтройВысоты', NOTIFY_EMAIL))
    msg['To'] = NOTIFY_EMAIL
    with smtplib.SMTP_SSL('smtp.mail.ru', 465, timeout=8) as server:
        server.login(NOTIFY_EMAIL, password)
        server.sendmail(NOTIFY_EMAIL, [NOTIFY_EMAIL], msg.as_string())


def handler(event: dict, context) -> dict:
    """Приём заявок с сайта (сохранение в базу, фото в хранилище, письмо на почту) и управление ими из админки."""
    method = event.get('httpMethod', 'GET')
    if method == 'OPTIONS':
        return {'statusCode': 200, 'headers': CORS, 'body': ''}

    params = event.get('queryStringParameters') or {}
    body = json.loads(event.get('body') or '{}') if method in ('POST', 'PUT') else {}

    if method == 'POST' and params.get('action') == 'login':
        return resp(200, {'ok': True}) if is_admin(event) else resp(401, {'error': 'Неверный пароль'})

    if method == 'POST':
        name = str(body.get('name', '')).strip()[:200]
        phone = str(body.get('phone', '')).strip()[:50]
        if len(name) < 2 or sum(c.isdigit() for c in phone) < 10:
            return resp(400, {'error': 'Укажите имя и телефон'})
        lead = {
            'name': name,
            'phone': phone,
            'service': str(body.get('service') or '')[:300],
            'address': str(body.get('address') or '')[:500],
            'comment': str(body.get('comment') or '')[:3000],
            'source': str(body.get('source') or '')[:50],
            'photos': upload_photos(body.get('photos') or []),
        }
        photos_sql = 'ARRAY[' + ','.join(q(u) for u in lead['photos']) + ']::text[]' if lead['photos'] else "'{}'"
        conn = psycopg2.connect(os.environ['DATABASE_URL'])
        cur = conn.cursor()
        cur.execute(
            f"INSERT INTO {SCHEMA}.leads (name, phone, service, address, comment, photos, source) VALUES "
            f"({q(lead['name'])}, {q(lead['phone'])}, {q(lead['service'])}, {q(lead['address'])}, "
            f"{q(lead['comment'])}, {photos_sql}, {q(lead['source'])}) RETURNING id"
        )
        lead_id = cur.fetchone()[0]
        conn.commit()
        conn.close()
        try:
            send_email(lead)
        except Exception as e:
            print(f'email error: {e}')
        return resp(200, {'ok': True, 'id': lead_id})

    if not is_admin(event):
        return resp(401, {'error': 'Нужен вход в админку'})

    conn = psycopg2.connect(os.environ['DATABASE_URL'])
    cur = conn.cursor()

    if method == 'GET':
        cur.execute(f"SELECT id, created_at, name, phone, service, address, comment, photos, source, status "
                    f"FROM {SCHEMA}.leads ORDER BY created_at DESC LIMIT 500")
        cols = [d[0] for d in cur.description]
        rows = [dict(zip(cols, r)) for r in cur.fetchall()]
        conn.close()
        return resp(200, {'leads': rows})

    lead_id = int(params.get('id') or body.get('id') or 0)
    if method == 'PUT':
        status = body.get('status')
        if status not in STATUSES:
            conn.close()
            return resp(400, {'error': 'Неверный статус'})
        cur.execute(f"UPDATE {SCHEMA}.leads SET status = {q(status)} WHERE id = {lead_id}")
    elif method == 'DELETE':
        cur.execute(f"DELETE FROM {SCHEMA}.leads WHERE id = {lead_id}")
    conn.commit()
    conn.close()
    return resp(200, {'ok': True})
