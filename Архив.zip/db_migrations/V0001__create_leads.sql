CREATE TABLE t_p29809016_belstroivysoty.leads (
  id SERIAL PRIMARY KEY,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  name VARCHAR(200) NOT NULL,
  phone VARCHAR(50) NOT NULL,
  service VARCHAR(300),
  address VARCHAR(500),
  comment TEXT,
  photos TEXT[] NOT NULL DEFAULT '{}',
  source VARCHAR(50),
  status VARCHAR(20) NOT NULL DEFAULT 'new'
);
CREATE INDEX leads_created_at_idx ON t_p29809016_belstroivysoty.leads (created_at DESC);